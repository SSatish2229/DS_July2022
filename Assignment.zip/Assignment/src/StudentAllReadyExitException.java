
public class StudentAllReadyExitException extends Exception
{
	public StudentAllReadyExitException(String msg)
	{
		super(msg);
	}
}
