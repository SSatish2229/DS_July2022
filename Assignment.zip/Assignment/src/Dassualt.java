import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Dassualt 
{
	public static void main(String[] args) 
	{
		Scanner s1 = new Scanner(System.in);
		company c1 = new company();
		System.out.println("HOW MUCH TIME YOU WANT TO INSERT DEPARTMENT NAME: ");
		int n = s1.nextInt();
		
		String name1 = s1.nextLine();
		for(int i=0; i<=n ;i++)
		{
			System.out.println("ENTER DEPARTMENT NAME: ");
			String name = s1.nextLine();
		
			System.out.println("ENTER LOCATION: ");
			String location = s1.nextLine();
			
			c1.User();
			System.out.println("DEPARTMENT NAME: "+name);
			System.out.println("LOCATION: "+location);
			c1.Employee();
		}
	}
}

class company
{
	private int id;
	private String name;
	private String location;
	private int numberOfEmployee;
	
	public int getId() 
	{
		return id;
	}
	
	public void setId(int id) 
	{
		this.id = id;
	}
	
	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	public String getLocation() 
	{
		return location;
	}
	
	public void setLocation(String location) 
	{
		this.location = location;
	}
	
	public int getNumberOfEmployee() 
	{
		return numberOfEmployee;
	}
	
	public void setNumberOfEmployee(int numberOfEmployee) 
	{
		this.numberOfEmployee = numberOfEmployee;
	}
	
	private static AtomicInteger ID_GENERATOR = new AtomicInteger(10);
	public void User() 
	{
	    id = ID_GENERATOR.getAndIncrement();
	    System.out.println("ID : "+id);   
	}
	
	private static AtomicInteger EMPLOYEE_GENERATOR = new AtomicInteger();
	public void Employee() 
	{
		numberOfEmployee = EMPLOYEE_GENERATOR.getAndIncrement();
	    System.out.println("EMPLOYEE NUMBER : "+numberOfEmployee);    
	}
}

