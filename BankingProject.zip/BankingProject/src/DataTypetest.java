
public class DataTypetest {

	public static void main(String[] args) 
	{
		byte b =-128;
		System.out.println("b is a BYTE "+b);
		System.out.println("Min Value For a Byte is : "+Byte.MIN_VALUE);
		System.out.println("Max Value For a Byte is : "+Byte.MAX_VALUE);
		System.out.println("Size of Byte variable : "+Byte.SIZE+ "bits");
		System.out.println("-----------------------------------------------------");

		short s = 228;
		System.out.println("s is a SHORT "+s);
		System.out.println("Min Value For a Byte is : "+Short.MIN_VALUE);
		System.out.println("Max Value For a Byte is : "+Short.MAX_VALUE);
		System.out.println("Size of Byte variable : "+Short.SIZE+ "bits");
		System.out.println("--------------------------------------------");
		
		int i = 123228;
		System.out.println("s is a INT "+s);
		System.out.println("Min Value For a Byte is : "+Integer.MIN_VALUE);
		System.out.println("Max Value For a Byte is : "+Integer.MAX_VALUE);
		System.out.println("Size of Byte variable : "+Integer.SIZE+ "bits");
		System.out.println("--------------------------------------------------");
		
		long l = 13223228;
		System.out.println("s is A LONG "+s);
		System.out.println("Min Value For a Byte is : "+Long.MIN_VALUE);
		System.out.println("Max Value For a Byte is : "+Long.MAX_VALUE);
		System.out.println("Size of Byte variable : "+Long.SIZE+ "bits");
		System.out.println("--------------------------------------------------------");
		
		float f = 1 ;
		System.out.println("s is A FLOAT "+f);
		System.out.println("Min Value For a Byte is : "+Float.MIN_VALUE);
		System.out.println("Max Value For a Byte is : "+Float.MAX_VALUE);
		System.out.println("Size of Byte variable : "+Float.SIZE+ "bits");
		System.out.println("-------------------------------------------------------");
		
		double d = 2.3;
		System.out.println("s is A DOUBLE "+d);
		System.out.println("Min Value For a Byte is : "+Double.MIN_VALUE);
		System.out.println("Max Value For a Byte is : "+Double.MAX_VALUE);
		System.out.println("Size of Byte variable : "+Double.SIZE+ "bits");
		
	}

}
