package com.ds.exceptions;

public class WashingMachineTubImbalancedException extends RuntimeException {

	public WashingMachineTubImbalancedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
