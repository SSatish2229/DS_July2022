package com.ds.exceptions;

public class WashingMachineOverloadedException extends RuntimeException
{

	public WashingMachineOverloadedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}