package com.ds.exceptions;

public class WashingMachineIsNotSwitchedOnException extends Exception
{
	public WashingMachineIsNotSwitchedOnException(String msg) {
		super(msg);
	}
}