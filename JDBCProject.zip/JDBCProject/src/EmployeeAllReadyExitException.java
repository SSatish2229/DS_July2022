
public class EmployeeAllReadyExitException extends Exception
{
	public EmployeeAllReadyExitException(String msg)
	{
		super(msg);
	}
}
